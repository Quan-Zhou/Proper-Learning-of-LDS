clear all
close all

num=10; % 20 noise standard deviations
repeat=30; % repeating times at the same noise std
met=3; % the number of system identification methods

std=linspace(0.1,1,num);
nrmse=cell(num,repeat,met);
T=20;

for n=1:num
   s=std(n);
   for r=1:repeat
       fit_tmp=CompareSysIden(T,s,s);
       for m=1:met
           nrmse{n,r,m}=fit_tmp{m,1};
       end
   end
end

yData=cell(met+1,1);
errors=cell(met+1,2);
for m=1:met
    nrmse_tmp=nrmse(:,:,m);
    fit=cell2mat(nrmse_tmp);
    fit_sort=sort(fit,2);
    yData{m,1}=mean(fit,2);
    errors{m,1}=fit_sort(:,floor(repeat*0.05));
    errors{m,2}=fit_sort(:,ceil(repeat*0.95));
end

data = csvread('Zout.csv');
Z = transpose(data*100);

yData{met+1,1}=mean(Z,2);

Zsort=sort(Z,2);
errors{met+1,1}=Zsort(:,floor(repeat*0.05));
errors{met+1,2}=Zsort(:,ceil(repeat*0.95));

options.errors = errors;
options.errorStyle = {'--'};
options.errorColors = [.55 .55 1
	.55 1 .55
	1 .55 .55
    .5 .5 .5];

options.colors = [.55 .55 1
	.55 1 .55
	1 .55 .55
    .5 .5 .5];

options.title = '';
options.xlabel = 'noise std';
options.ylabel = 'nrmse(%)';
options.legend = {'least squares auto','subspace auto','ssarx','our method'};%{,'N4sid'
options.legendLoc = 'SouthEast';
options.labelLines = 0;
options.errorFill = 0;
options.lineWidth = 1.5;

figure;
prettyPlot(std,yData,options);
xlim([0.1 1.0])
xticks([0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0])
ylim([-800 150])
yticks([-800 -400 0 50 100])

