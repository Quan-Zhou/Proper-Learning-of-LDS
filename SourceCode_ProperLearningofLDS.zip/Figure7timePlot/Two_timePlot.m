clear all
close all

%% Experiment
% "Least squares auto" method
load setting6;
start=1;
stop=200;
step=4;
Y=transpose(seq_d0(start:step:stop));
T=size(Y,1);
inputs = zeros(T,1); % Inputs are all zeros
z = iddata(Y,inputs,T);

order = 1;
opt = ssestOptions;
def = ssest(z,order,'Ts',T,opt);
[sim,fit,~]=compare(z,def);

% Our method
% Read from 'stock_NCPO.csv'
stock_NCPO=csvread('stock_NCPO.csv');

%% Plot
hold on
plot(Y, 'linestyle',':','marker','+','markersize',10,'color','g','linewidth',2);
plot(stock_NCPO,'color','m','linewidth',2);
plot(sim.outputdata,'color','b','linewidth',2);
legend_str=cell(3,1);
legend_str{1}= ['estimation data'];
legend_str{2}= ['our method 95.73%'];
legend_str{3}= ['least squares auto ' num2str(fit, '%4.2f') '%'];
legend(legend_str,'Location','NorthWest')
xlabel('time t')
ylabel('value f(t)')
ylim([30,41]);
hold off

save Two_timePlot_workspace